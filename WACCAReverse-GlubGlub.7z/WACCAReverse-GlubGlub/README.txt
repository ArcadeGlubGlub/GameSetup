Hi! Welcome to Glub Glub's WACCA Reverse setup environment.

# [!] Running the setup script will modify the data.
# If you don't want to do this, don't run the script!

# [i] If you want to use your own WACVR, extract it into the WACVR folder.
# This is only typically done if you are developing for WACVR.

Instructions:
1. Add your WACCA data to the Game\app folder. This folder should include just the game files,
which include the bin and WindowsNoEditor folders, as well as the other files.
**IT IS IMPORTANT THAT YOUR DATA IS CLEAN.**
**NO ADDED SEGATOOLS OR OTHER FILES LIKE SERVER EMULATORS.**

2. Next, setup the game by right-clicking the "Setup.ps1" file and clicking Run with PowerShell.
(You may need to allow script execution in Windows Settings, if it doesn't run. Google for information.)
This script will automate:
- Installing Segatools and mercuryio.dll
- Configuring segatools.ini
- Renaming game.bat so you don't accidentally launch it
- Downloading and setting up WACVR to autolaunch data
- Downloading the required D2XX driver to get LEDs to work
- Creating a shortcut to launch the game
- Cleaning up leftover files from setup

3. Open SteamVR or the Oculus app first, then open the "Launch" shortcut,
which starts WACVR and WACCA simultaneously.

Have fun! Glub glub! ;3