# Configuration for this setup script
$gamefolder = "$PSScriptRoot\Game\app\bin"
$title = "Glub Glub Game Setup"
$game = "WACCA"
$guide = "the README.txt file"
$channel = "the WACVR Discord"

# Dependencies
$sturl = "https://wacvr.cf/mercury.zip"
$stoutpath = "$PSScriptRoot\segatools.zip"
$stfilekey = "$gamefolder\start.bat"
$iourl = "https://wacvr.cf/mercuryio.dll"
$iofilekey = "$gamefolder\mercuryio.dll"
$d2xxurl = "https://www.ftdichip.com/Drivers/CDM/CDM%20v2.12.36.4%20WHQL%20Certified.zip"
$d2xxoutpath = "$PSScriptRoot\d2xx.zip"
$d2xxfilekey = "$PSScriptRoot\Game\app\WindowsNoEditor\Mercury\Binaries\Win64\ftd2xx.dll"
$d2xxdestfolder = "$PSScriptRoot\Game\app\WindowsNoEditor\Mercury\Binaries\Win64"

# segatools.ini edits
$editpath = "$gamefolder\segatools.ini"
$amfskey = "amfs=amfs"
$appdatakey = "appdata=appdata"
$optionkey = "option=option"
$amfspath = "amfs=$PSScriptRoot\Game\amfs"
$appdatapath = "appdata=$PSScriptRoot\Game\appdata"
$optionpath = "option=$PSScriptRoot\Game\option"
$urlkey = "default=127.0.0.1"
$serverkey = "default=enter_default_server_here"
$iocomment = ";\[mercuryio]"
$iokey = "[mercuryio]"
$iopathcomment = ";path=mercuryio.dll"
$iopath = "path=mercuryio.dll"

# WACVR files
$wacvrurl = "https://nightly.link/xiaopeng12138/WACVR/workflows/build/main/artifact.zip"
$wacvroutpath = "$PSScriptRoot\wacvr.zip"
$wacvrfolder = "$PSScriptRoot\WACVR"
$wacvrfilekey = "$wacvrfolder\WACVR.exe"
$wacvrconfig = "$wacvrfolder\config.json"
$wacvrbatconfigkey = '"batFileLocation": ""'
$wacvrbatconfig = '"batFileLocation": "' + $stfilekey.Replace("\", "\\") + '"'
$wacvrlog = "$wacvrfolder\uWindowCapture.log"

# DefaultHardware.ini edits
$defaulthardwarepath = "$PSScriptRoot\Game\app\WindowsNoEditor\Mercury\Config\DefaultHardware.ini"
$defaulttimeoutkey = "TimeoutSecondsNetworkTest=180.0"
$modifiedtimeoutkey = "TimeoutSecondsNetworkTest=1.0"
$defaulterrorkey = "bEnableErrorWatcher=true"
$modifiederrorkey = "bEnableErrorWatcher=false"

# game.bat file
$gamebatkey = "$PSScriptRoot\Game\app\game.bat"

# Launchers
$lnfilekey = "$PSScriptRoot\Launch.lnk"

$host.ui.RawUI.WindowTitle = "$title - $game"
$wc = New-Object System.Net.WebClient

function Change-Network {
    Write-Output "Replacing default server URL (if existing)..."
    ((Get-Content -path "$editpath" -Raw) -replace "$urlkey","$serverkey") | Set-Content -NoNewline -Path $editpath
}

function Change-Paths {
    Write-Output "Replacing default game paths (if existing)..."
    ((Get-Content -path "$editpath" -Raw) -replace "$amfskey","$amfspath") | Set-Content -NoNewline -Path $editpath
    ((Get-Content -path "$editpath" -Raw) -replace "$appdatakey","$appdatapath") | Set-Content -NoNewline -Path $editpath
    ((Get-Content -path "$editpath" -Raw) -replace "$optionkey","$optionpath") | Set-Content -NoNewline -Path $editpath
}

function Uncomment-IO {
    Write-Output "Uncommenting IO lines (if commented)..."
    ((Get-Content -path "$editpath" -Raw) -replace "$iocomment","$iokey") | Set-Content -NoNewline -Path $editpath
    ((Get-Content -path "$editpath" -Raw) -replace "$iopathcomment","$iopath") | Set-Content -NoNewline -Path $editpath
}

function Change-Hardware {
    Write-Output "Changing DefaultHardware.ini settings (if unchanged)..."
    ((Get-Content -path "$defaulthardwarepath" -Raw) -replace "$defaulttimeoutkey","$modifiedtimeoutkey") | Set-Content -NoNewline -Path $defaulthardwarepath
    ((Get-Content -path "$defaulthardwarepath" -Raw) -replace "$defaulterrorkey","$modifiederrorkey") | Set-Content -NoNewline -Path $defaulthardwarepath
}

function Rename-Gamebat {
    if (Test-Path -Path $gamebatkey -PathType Leaf) {
        Write-Output "Renaming game.bat..."
        Rename-Item -Path "$gamebatkey" -NewName "game.bat.disabled"
    } else {
        Write-Output "game.bat does not exist, skipping..."
    }
}

function Add-Segatools {
    if (-not(Test-Path -Path $stfilekey -PathType Leaf)) {
        Write-Output "Downloading Segatools..."
        $wc.DownloadFile($sturl, $stoutpath)
        Write-Output "Extracting Segatools..."
        Expand-Archive -LiteralPath "$stoutpath" -DestinationPath "$gamefolder"
        Write-Output "Cleaning up..."
        Remove-Item -recurse "$stoutpath"
    } else {
        Write-Output "Segatools already added, skipping..."
    }
}

function Add-D2XX-Driver {
    if (-not(Test-Path -Path $d2xxfilekey -PathType Leaf)) {
        Write-Output "Downloading D2XX driver..."
        $wc.DownloadFile($d2xxurl, $d2xxoutpath)
        Write-Output "Extracting D2XX driver..."
        Expand-Archive -LiteralPath "$d2xxoutpath" -DestinationPath "$PSScriptRoot\d2xx"
        Write-Output "Moving ftd2xx64.dll next to Mercury..."
        Move-Item -LiteralPath "$PSScriptRoot\d2xx\amd64\ftd2xx64.dll" -Destination "$d2xxdestfolder"
        Write-Output "Renaming ftd2xx64.dll to ftd2xx.dll..."
        Rename-Item -Path "$d2xxdestfolder\ftd2xx64.dll" -NewName "ftd2xx.dll"
        Write-Output "Cleaning up..."
        Remove-Item -recurse "$d2xxoutpath"
        Remove-Item -recurse "$PSScriptRoot\d2xx"
    } else {
        Write-Output "D2XX driver already added, skipping..."
    }
}

function Setup-WACVR {
    if (-not(Test-Path -Path $wacvrfilekey -PathType Leaf)) {
        Write-Output "Downloading WACVR..."
        $wc.DownloadFile($wacvrurl, $wacvroutpath)
        Write-Output "Extracting WACVR..."
        Expand-Archive -LiteralPath "$wacvroutpath" -DestinationPath "$wacvrfolder"
        Write-Output "Cleaning up..."
        Remove-Item -recurse "$wacvroutpath"
        Remove-Item -recurse "$wacvrfolder\WACVR_BurstDebugInformation_DoNotShip"
    } else {
        Write-Output "WACVR already added, skipping..."
    }
    if (-not(Test-Path -Path $wacvrconfig -PathType Leaf)) {
        Write-Output "Launching WACVR..."
        Start-Process -FilePath "$wacvrfilekey" -WorkingDirectory "$wacvrfolder"
        Write-Output "Waiting for WACVR to generate a configuration file..."
        while (!(Test-Path "$wacvrconfig")) { Start-Sleep 1 }
        Write-Output "Closing WACVR..."
        Stop-Process -Name "WACVR"
        Wait-Process -Name "WACVR"
        while ((Get-Process -Name "WACVR" -ErrorAction SilentlyContinue) -and (Test-Path "$wacvrlog")) { Start-Sleep 1 }
        Write-Output "Cleaning up..."
        Remove-Item "$wacvrlog"
    } else {
        Write-Output "WACVR configuration already exists, skipping..."
    }
    Write-Output "Modifying WACVR configuration (if not modified)..."
    ((Get-Content -path "$wacvrconfig" -Raw) -replace "$wacvrbatconfigkey","$wacvrbatconfig") | Set-Content -NoNewline -Path $wacvrconfig
}
function Create-Launcher {
    if (-not(Test-Path -Path $lnfilekey -PathType Leaf)) {
        Write-Output "Creating launcher..."
        $WshShell = New-Object -comObject WScript.Shell
        $Shortcut = $WshShell.CreateShortcut("$lnfilekey")
        $Shortcut.TargetPath = "$wacvrfilekey"
        $Shortcut.WorkingDirectory = $wacvrfolder
        $Shortcut.IconLocation = "$PSScriptRoot\Options\icon.ico"
        $Shortcut.Save()
    } else {
        Write-Host "Launcher already added, skipping..."
    }
}

function Add-MercuryIO {
    if (-not(Test-Path -Path $iofilekey -PathType Leaf)) {
        Write-Output "Downloading Mercury IO..."
        $wc.DownloadFile($iourl, $iofilekey)
    } else {
        Write-Output "Mercury IO already added, skipping..."
    }
}

function Prompt-Finished {
    Write-Host "`nSetup finished.`n"
    Write-Host "All done! Please go to $guide for the next steps."
    Write-Host "If you need troubleshooting help, ask in $channel."
    Write-Host "Press any key to exit."
    $null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown');
}

function New-Screen {
    Clear-Host
    Write-Host "===== NOT FOR PUBLIC DISTRIBUTION OF ARCADE DATA ====="
    Write-Host "================ $title ================"
    Write-Host ""
}

function Menu-Introduction {
    Write-Host "Hello! Welcome to the setup script!"
    Write-Host "This will automatically setup $game for WACVR."
    Write-Host "You should be following $guide if you're using this script!"
    Write-Host "Make sure that your WACCA data is in Game\app as instructed."
    Write-Host ""
    Write-Host "Once again, consult README.txt if you haven't before starting."
    Write-Host ""
    Write-Host "y: Start setup"
    Write-Host "q: Quit setup"
}

function Menu-NotForPublic {
    Write-Host "Warning: If you came here from a YouTube tutorial on setting up WACCA in VR,
please note that we do not condone public sharing of game data."
    Write-Host "Team Glub Glub does not encourage our scripts to be used to facilitiate
easier sharing of pirated copies of arcade games."
    Write-Host "If we see this happening again, we will stop work on releasing setup environments
for future games like maimai DX, and pull all of our released environments."
    Write-Host "We suggest to stop using this script if you originate from this tutorial."
    Write-Host ""
    Write-Host "Additionally, we would also like to request anyone currently using our setup
environments to assist in public access to respectfully cease operations."
    Write-Host "While we are an anonymous group, we still are active in places this happens in,
and we don't like seeing our tools being used to publically promote pirated copies."
    Write-Host ""
    Write-Host "Support your local arcade if you can, thank you!"
    Write-Host ""
}

# Menu logic
New-Screen
Menu-NotForPublic
Write-Host "[i] Setup will continue in 20 seconds."
Start-Sleep -Seconds 20

New-Screen
Menu-NotForPublic
Write-Host "--> Press any key to agree to this statement."
$null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown');

New-Screen
Menu-Introduction
$selection = Read-Host "Type your selection and press Enter"
switch ($selection)
    {
        'y' {
            New-Screen

            Write-Output "[Step 1/2] WACCA Setup"
            Add-Segatools
            Add-MercuryIO
            Change-Paths
#            Change-Network
            Uncomment-IO
#           Change-Hardware
            Add-D2XX-Driver
            Rename-Gamebat

            Write-Output "`n[Step 2/2] WACVR Setup"

            Setup-WACVR
            Create-Launcher
            Prompt-Finished
        }
    }